// Top-level build file. It only declares WHICH build plugins (and versions)
// the project uses. The real settings are in app/build.gradle.kts.
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
}
