# TV File Drop

Send files from an iPad (Safari) to an Android TV over your home Wi-Fi.
No app on the iPad: the TV shows a web address, you open it, pick files, tap Upload.

> **Honest note:** this project was written carefully but has **not been compiled
> or run on a TV** (it was written without an Android SDK). If the first build
> shows an error, copy the red message and ask for a fix - it will most likely be small.

---

## 1. Project structure

```
TVFileDrop/
├── settings.gradle.kts            where Gradle downloads things from
├── build.gradle.kts               build plugin versions
├── gradle.properties              build settings
├── gradle/wrapper/gradle-wrapper.properties   which Gradle version to use
└── app/
    ├── build.gradle.kts           app settings + the 2 libraries
    └── src/main/
        ├── AndroidManifest.xml    permissions, the screen, the service
        ├── assets/index.html      the iPad web page (HTML + CSS + JS in one file)
        ├── java/com/example/tvfiledrop/
        │   ├── MainActivity.kt    the TV screen and its buttons
        │   ├── UploadService.kt   foreground service that keeps the server alive
        │   ├── WebServer.kt       answers the iPad, streams uploads to disk
        │   ├── Storage.kt         where files go (internal / USB / picked folder)
        │   ├── Prefs.kt           remembered settings (location, PIN, recent files)
        │   ├── AppState.kt        shared "notice board" between server and screen
        │   ├── NetUtils.kt        finds the TV's IP address
        │   └── QrCode.kt          draws the QR code
        └── res/
            ├── layout/activity_main.xml    the screen layout
            ├── drawable/button_bg.xml      button look (normal / focused / pressed)
            ├── drawable/banner.xml         home-screen banner
            ├── drawable/ic_app.xml         app icon
            ├── drawable/ic_notification.xml
            ├── color/button_text.xml       button text colour per state
            └── values/ (strings, colors, styles)
```

Every file is commented line by line. A good reading order to learn from it:
`AppState` → `NetUtils` → `Prefs` → `WebServer` → `Storage` → `UploadService` → `MainActivity` → `index.html`.

## 2. How it works (the short story)

1. You open the app. `MainActivity` starts `UploadService`.
2. The service shows a notification (that is what makes it a *foreground* service,
   which Android does not kill) and starts `WebServer` on port 8080.
3. The screen shows `http://<TV address>:8080` and a QR code of it.
4. Safari opens that address; `WebServer` answers with `index.html`.
5. For each file, the page sends one request whose **body is the file itself**.
   `WebServer` reads 64 KB, writes 64 KB to disk, and repeats. A 5 GB video
   therefore needs 64 KB of memory, not 5 GB.
6. The server writes progress into `AppState`; the screen redraws from it.

**Why not a normal HTML form upload ("multipart")?** NanoHTTPD would first save
the whole upload into a temporary file on internal storage and only then let us
copy it. A big video could fill the TV's small internal storage before it ever
reaches the USB drive. Sending the raw file avoids the temporary copy.

## 3. Where files are saved, and why

Android 11 does not let an app write wherever it wants ("scoped storage").
The app offers every legal way, in the **Change location** list:

| Entry in the list | Folder | Permission | Other apps can open it | Survives uninstall |
|---|---|---|---|---|
| Internal storage → Download/TVFileDrop (default) | `Download/TVFileDrop` | none | yes | yes |
| USB: … → Download/TVFileDrop | `Download/TVFileDrop` on the drive | none | yes | yes |
| … → app folder | `Android/data/com.example.tvfiledrop/files/Received` | none | **no** (Android 11+) | **no - deleted** |
| Choose any folder with the system picker | whatever you pick | granted by the picker | yes | yes |

- The **Download** entries use *MediaStore*: Android lets any app add files to
  Download without permission, on internal storage and on USB drives. This is
  why the app does not need "All files access".
- The **app folder** entries always work, even on the most locked-down TV.
  **Warning:** Android deletes that folder when you uninstall the app. Before
  uninstalling, plug the drive into a computer and copy the files out, or use a
  Download entry instead. The app shows this warning when you pick one.
- The **system picker** line only works if your TV has the picker. The app
  checks; on many TCL TVs it will say "not available".
- If a "USB: … → Download" entry is missing for your drive, the TV's MediaStore
  does not index that drive; use the app-folder entry for it.
- Same name twice? The new file becomes `video (1).mp4`. Nothing is overwritten.
- The choice is remembered. If the USB drive is unplugged, files go to internal
  storage until it is back (the screen says so).

## 4. Permissions (all three are granted automatically, no pop-ups)

| Permission | Why |
|---|---|
| `INTERNET` | To open a network port so the iPad can connect. Nothing is sent to the internet. |
| `FOREGROUND_SERVICE` | To keep receiving when you leave the app's screen. |
| `FOREGROUND_SERVICE_DATA_SYNC` | Android 14+ requires naming the service type. Ignored on your Android 11. |

No storage permission, no location, no "All files access".

## 5. Build the APK

1. Install **Android Studio** (developer.android.com/studio) on your computer.
2. Unzip `TVFileDrop.zip`. In Android Studio: **File → Open** → select the
   `TVFileDrop` folder (the one containing `settings.gradle.kts`).
3. Wait for "Gradle sync" to finish (first time: several minutes, it downloads
   Gradle, the Android SDK 34 and the two libraries). Accept any SDK licence prompts.
   - If Studio offers to **upgrade the Android Gradle Plugin**, you can decline.
   - If sync complains about the **JDK version**: Settings → Build, Execution,
     Deployment → Build Tools → Gradle → *Gradle JDK* → pick version 17 or 21.
4. Menu **Build → Build App Bundle(s) / APK(s) → Build APK(s)**
   (in newer versions: **Build → Generate App Bundles or APKs → Generate APKs**).
5. The file is at `app/build/outputs/apk/debug/app-debug.apk`.

## 6. Turn on Developer options on the TCL TV

Menu names differ slightly between TCL models; look for the closest match.

1. **Settings → Device Preferences → About** (on some models: Settings → System → About).
2. Scroll to **Build** and press **OK seven times** until "You are now a developer" appears.
3. Go back: **Device Preferences → Developer options**.
4. Turn on **USB debugging**. On Android TV 11 this normally also allows
   debugging over the network. If you see a separate **Network / ADB debugging**
   switch, turn that on as well.
5. Note the TV's IP address: **Settings → Network & Internet** → select your network.

## 7. Install on the TV

### Option A - adb over Wi-Fi (recommended)

`adb` comes with Android Studio, in the SDK folder `platform-tools`
(Studio shows the SDK path under Settings → Languages & Frameworks → Android SDK).
The computer and TV must be on the same network.

```
adb connect 192.168.1.20:5555      (use your TV's IP)
```
The TV shows "Allow USB debugging?" → tick "Always allow" → **Allow**. Then:
```
adb devices                        (the TV should be listed as "device")
adb install -r app/build/outputs/apk/debug/app-debug.apk
```
You can also press the green **Run ▶** button in Android Studio once the TV
appears in the device list - it builds and installs in one step.

### Option B - USB stick

Copy `app-debug.apk` to a USB stick, plug it into the TV, open it with a file
manager app on the TV, and allow "Install unknown apps" for that file manager
when asked (Settings → Apps → Security & restrictions → Unknown sources).

### Option C - Downloader app

Upload `app-debug.apk` somewhere that gives you a direct download link, install
**Downloader** from the Play Store on the TV, type the link, and allow
"Install unknown apps" for Downloader.

## 8. Using it

1. Open **TV File Drop** on the TV. The server starts by itself.
2. On the iPad, scan the QR code with the Camera app, or type the address in Safari.
3. Tap **Choose files**, pick files, tap **Upload**. Keep Safari open until every file says **Done ✓**.
4. Optional: **Turn PIN on** on the TV; the page then asks for the 4 digits.

## 9. Troubleshooting

**The iPad cannot open the address**
- Both devices must be on the *same* Wi-Fi (not a "guest" network, and not one on Wi-Fi and one on mobile data).
- Type `http://` at the start. Safari may try `https://`, which will not work.
- The address on the TV changes if the router gives the TV a new IP; re-read it from the screen.
- Some routers have "AP isolation / client isolation", which stops devices from talking to each other. Turn it off in the router settings.
- Check the TV says "Waiting for files…". If not, press **Start server**.

**The USB drive is not in the list**
- Unplug it, plug it back in, wait 10 seconds, open **Change location** again.
- The drive must be formatted FAT32 or exFAT (NTFS is often read-only or unsupported on TVs).
- If the TV asked to "set up as device storage", choose *removable/portable* storage instead.
- Only the "app folder" entry appears: that is normal on some TVs (see section 3).

**An upload fails**
- The TV's status line shows the real reason.
- *"File too big for this drive"*: FAT32 cannot hold a file over 4 GB. Reformat the drive as exFAT (if your TV reads exFAT) or save to internal storage.
- *"The storage is full"*: free some space or choose another location.
- *"The connection was lost"*: the iPad went to sleep or Safari was moved to the background. Keep the page open and on screen; for very large files, set the iPad's Auto-Lock to "Never" for a while.
- Photos picked from the Photos library may arrive converted (for example HEIC → JPEG). Choose from **Files** if you need the untouched original.
- Wrong PIN five times → wait one minute.

**The app does not appear on the TV home screen**
- Look in **Settings → Apps → See all apps**. Sideloaded apps are sometimes only listed there on TCL launchers.

## 10. Ideas to extend it (good practice projects)

- Show free space next to each storage entry.
- Add a "Delete" action to the recent files list.
- Rebuild the screen with Jetpack Compose for TV once you are comfortable with this version.
