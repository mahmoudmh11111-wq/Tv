plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.tvfiledrop"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.tvfiledrop"
        minSdk = 24          // Android 7.0 - the oldest version the app installs on
        targetSdk = 34       // The Android version the app is written for
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // The tiny web server that runs inside the app (one small jar, no other dependencies).
    implementation("org.nanohttpd:nanohttpd:2.3.1")
    // Draws the QR code. "core" is only the encoder - no camera or scanner code.
    implementation("com.google.zxing:core:3.5.3")
}
