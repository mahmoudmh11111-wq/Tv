package com.example.tvfiledrop

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.storage.StorageManager
import android.os.storage.StorageVolume
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import java.io.File
import java.io.IOException
import java.io.OutputStream
import java.util.Locale

/**
 * One place where files can be saved.
 *
 * type  = HOW we write there (see the three TYPE_ constants in Storage)
 * value = WHERE exactly (a MediaStore volume name, a folder path, or a picker Uri)
 * label = the text shown to the user
 */
data class SaveLocation(val type: String, val value: String, val label: String)

/**
 * A file that is open for writing.
 *
 * out      = write the bytes here
 * finish() = call when everything was written; returns the final file name
 * abort()  = call if something went wrong; deletes the half-written file
 */
class OpenFile(
    val out: OutputStream,
    private val onFinish: () -> String,
    private val onAbort: () -> Unit
) {
    fun finish(): String = onFinish()

    fun abort() {
        try {
            onAbort()
        } catch (e: Exception) {
            // Nothing more we can do; ignore.
        }
    }
}

/**
 * Everything about WHERE files are saved.
 *
 * Android 11 has "scoped storage": an app may not write wherever it likes.
 * There are three legal ways to save a file, and this app supports all three:
 *
 * 1. TYPE_MEDIA  - "MediaStore". Android lets any app ADD files to the public
 *                  Download folder (on internal storage and on USB drives)
 *                  without any permission. Other apps can open these files and
 *                  they stay when this app is uninstalled. Needs Android 10+.
 *                  This is the default.
 *
 * 2. TYPE_APPDIR - The app's own folder (Android/data/<app>/files). Always
 *                  works, no permission. BUT other TV apps cannot look inside
 *                  it on Android 11+, and Android deletes it when the app is
 *                  uninstalled.
 *
 * 4. TYPE_FOLDER - Any folder chosen with the app's own folder browser.
 *                  Needs the "All files access" permission, which the user
 *                  must switch on once. Files are written like normal files.
 *
 * 3. TYPE_SAF    - "Storage Access Framework": the system folder picker. The
 *                  user picks any folder and Android gives us access to it.
 *                  Many TVs do not have this picker at all.
 */
object Storage {

    const val TYPE_MEDIA = "media"
    const val TYPE_APPDIR = "appdir"
    const val TYPE_SAF = "saf"
    const val TYPE_FOLDER = "folder"

    /** Sub-folder created inside Download. */
    private const val PUBLIC_FOLDER = "TVFileDrop"

    /** Sub-folder created inside the app's own folder. */
    private const val APP_FOLDER = "Received"

    /** MediaStore's name for the internal shared storage. */
    private const val INTERNAL_VOLUME = "external_primary"

    // ------------------------------------------------------------------
    // Listing and choosing locations
    // ------------------------------------------------------------------

    /** Where files go if the user never chose anything (or the USB drive is gone). */
    fun defaultLocation(ctx: Context): SaveLocation {
        return if (Build.VERSION.SDK_INT >= 29) {
            SaveLocation(
                TYPE_MEDIA, INTERNAL_VOLUME,
                "Internal storage → Download/$PUBLIC_FOLDER"
            )
        } else {
            internalAppDir(ctx)
        }
    }

    private fun internalAppDir(ctx: Context): SaveLocation {
        // getExternalFilesDir = the app's folder on the shared internal storage.
        // If that is missing (very rare) we use the fully private filesDir.
        val base = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        return SaveLocation(
            TYPE_APPDIR, File(base, APP_FOLDER).absolutePath,
            "Internal storage → app folder (hidden from other apps)"
        )
    }

    /**
     * Builds the list for the "Change location" dialog:
     * internal storage first, then every USB drive / SD card that is plugged in.
     */
    fun listLocations(ctx: Context): List<SaveLocation> {
        val list = ArrayList<SaveLocation>()
        list.add(defaultLocation(ctx))
        if (Build.VERSION.SDK_INT >= 29) {
            list.add(internalAppDir(ctx))
        }

        // getExternalFilesDirs returns one folder per storage volume:
        // [0] is internal storage, [1], [2], ... are USB drives and SD cards.
        // Calling it also makes Android CREATE our app folder on each drive.
        val dirs = ctx.getExternalFilesDirs(null)
        val storageManager = ctx.getSystemService(Context.STORAGE_SERVICE) as StorageManager
        for (i in 1 until dirs.size) {
            val dir = dirs[i] ?: continue                       // null = drive not ready
            if (Environment.getExternalStorageState(dir) != Environment.MEDIA_MOUNTED) continue

            val volume: StorageVolume? = storageManager.getStorageVolume(dir)
            val name = volume?.getDescription(ctx) ?: "USB drive"

            // Option A: public Download folder on the drive (Android 10+).
            if (Build.VERSION.SDK_INT >= 29) {
                val mediaName = mediaVolumeName(ctx, volume)
                if (mediaName != null) {
                    list.add(
                        SaveLocation(
                            TYPE_MEDIA, mediaName,
                            "USB: $name → Download/$PUBLIC_FOLDER"
                        )
                    )
                }
            }
            // Option B: the app's own folder on the drive (always works).
            list.add(
                SaveLocation(
                    TYPE_APPDIR, File(dir, APP_FOLDER).absolutePath,
                    "USB: $name → app folder (always works, hidden from other apps)"
                )
            )
        }
        return list
    }

    /**
     * MediaStore gives every drive a name (for USB drives: the drive's ID in
     * lower case). Returns null if MediaStore does not know this drive.
     */
    private fun mediaVolumeName(ctx: Context, volume: StorageVolume?): String? {
        if (volume == null || Build.VERSION.SDK_INT < 29) return null
        val name: String? = if (Build.VERSION.SDK_INT >= 30) {
            volume.mediaStoreVolumeName
        } else {
            volume.uuid?.lowercase(Locale.US)
        }
        if (name == null) return null
        return try {
            if (MediaStore.getExternalVolumeNames(ctx).contains(name)) name else null
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------------------------------------------------
    // The built-in folder browser ("Browse folders")
    // ------------------------------------------------------------------

    /**
     * The starting points for browsing: internal storage and every USB drive.
     * Each entry is (text to show, top folder of that storage).
     */
    @Suppress("DEPRECATION")
    fun browseRoots(ctx: Context): List<Pair<String, File>> {
        val roots = ArrayList<Pair<String, File>>()
        roots.add(Pair("Internal storage", Environment.getExternalStorageDirectory()))

        val dirs = ctx.getExternalFilesDirs(null)
        val storageManager = ctx.getSystemService(Context.STORAGE_SERVICE) as StorageManager
        for (i in 1 until dirs.size) {
            val dir = dirs[i] ?: continue
            if (Environment.getExternalStorageState(dir) != Environment.MEDIA_MOUNTED) continue
            // dir is ".../<drive>/Android/data/<app>/files". Cutting the path at
            // "/Android/data" leaves the top folder of the drive, e.g. /storage/1234-ABCD.
            val top = File(dir.absolutePath.substringBefore("/Android/data"))
            val name = storageManager.getStorageVolume(dir)?.getDescription(ctx) ?: "USB drive"
            roots.add(Pair("USB: $name", top))
        }
        return roots
    }

    /** The folders inside a folder, sorted by name. Hidden folders (".name") are skipped. */
    fun listSubfolders(dir: File): List<File> {
        val all = dir.listFiles() ?: return emptyList()
        return all
            .filter { it.isDirectory && !it.name.startsWith(".") }
            .sortedBy { it.name.lowercase(Locale.ROOT) }
    }

    /** A longer explanation shown after the user picks a location. */
    fun explain(loc: SaveLocation): String {
        return when (loc.type) {
            TYPE_MEDIA ->
                "Files will be saved in the folder Download/$PUBLIC_FOLDER on this storage.\n\n" +
                    "Why there: Android lets every app add files to the Download folder " +
                    "without asking for any permission. Video players and file managers " +
                    "can open the files, and they stay if you uninstall this app."
            TYPE_APPDIR ->
                "Files will be saved in:\n${loc.value}\n\n" +
                    "Why there: this is the app's own folder. Android always lets the app " +
                    "write here, even on TVs with no folder picker.\n\n" +
                    "WARNING: Android DELETES this folder when the app is uninstalled, and " +
                    "other TV apps cannot look inside it.\n\n" +
                    "To keep files safe: plug the drive into a computer and copy them out " +
                    "of Android/data/com.example.tvfiledrop/files/$APP_FOLDER before " +
                    "uninstalling - or choose a 'Download/$PUBLIC_FOLDER' location instead."
            TYPE_FOLDER ->
                "Files will be saved directly in:\n${loc.value}\n\n" +
                    "This works because you gave the app 'All files access'. They are " +
                    "normal files: other apps can open them and they stay if you " +
                    "uninstall this app."
            else ->
                "Files will be saved directly in the folder you picked. They are normal " +
                    "files: other apps can open them and they stay if you uninstall this app."
        }
    }

    // ------------------------------------------------------------------
    // Checking that a location still works (USB unplugged?)
    // ------------------------------------------------------------------

    fun isAvailable(ctx: Context, loc: SaveLocation): Boolean {
        return try {
            when (loc.type) {
                TYPE_MEDIA ->
                    Build.VERSION.SDK_INT >= 29 &&
                        MediaStore.getExternalVolumeNames(ctx).contains(loc.value)

                TYPE_APPDIR -> {
                    ctx.getExternalFilesDirs(null)      // makes Android create the app folders
                    val dir = File(loc.value)
                    (dir.isDirectory || dir.mkdirs()) && dir.canWrite()
                }

                TYPE_SAF -> isSafFolderReachable(ctx, Uri.parse(loc.value))

                // False if the drive was unplugged or the permission was taken away.
                TYPE_FOLDER -> {
                    val dir = File(loc.value)
                    dir.isDirectory && dir.canWrite()
                }

                else -> false
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun isSafFolderReachable(ctx: Context, tree: Uri): Boolean {
        // 1. Do we still hold the permission the picker gave us?
        val hasPermission = ctx.contentResolver.persistedUriPermissions.any {
            it.uri == tree && it.isWritePermission
        }
        if (!hasPermission) return false
        // 2. Does the folder still answer? (It will not if the drive was unplugged.)
        val folder = DocumentsContract.buildDocumentUriUsingTree(
            tree, DocumentsContract.getTreeDocumentId(tree)
        )
        val cursor = ctx.contentResolver.query(
            folder, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID), null, null, null
        ) ?: return false
        // "use" closes the cursor for us when we are done with it.
        return cursor.use { it.moveToFirst() }
    }

    /**
     * The location to use RIGHT NOW.
     * Returns the saved choice if it works; otherwise internal storage.
     * The second value is true when we had to fall back. The saved choice is
     * kept, so the USB drive is used again as soon as it is plugged back in.
     */
    fun resolve(ctx: Context): Pair<SaveLocation, Boolean> {
        val saved = Prefs.getLocation(ctx) ?: return Pair(defaultLocation(ctx), false)
        if (isAvailable(ctx, saved)) return Pair(saved, false)
        return Pair(defaultLocation(ctx), true)
    }

    // ------------------------------------------------------------------
    // File names
    // ------------------------------------------------------------------

    /**
     * Makes a file name from the iPad safe to use on the TV:
     * no folder parts, no characters that USB drives (FAT/exFAT) forbid,
     * and not too long.
     */
    fun cleanFileName(raw: String): String {
        var name = raw.substringAfterLast('/').substringAfterLast('\\')
        val sb = StringBuilder()
        for (ch in name) {
            if (ch.code < 32 || ch.code == 127) continue          // control characters
            if ("\\/:*?\"<>|".indexOf(ch) >= 0) sb.append('_') else sb.append(ch)
        }
        name = sb.toString().trim().trimStart('.').trimEnd('.', ' ')
        if (name.isEmpty()) name = "file"

        // Keep it short but keep the extension (.mp4, .jpg, ...).
        if (name.length > 100) {
            val dot = name.lastIndexOf('.')
            val ext = if (dot > 0 && name.length - dot <= 10) name.substring(dot) else ""
            name = name.substring(0, 100 - ext.length).trim() + ext
        }
        return name
    }

    /** numbered("video.mp4", 0) = "video.mp4",  numbered("video.mp4", 2) = "video (2).mp4" */
    private fun numbered(name: String, n: Int): String {
        if (n == 0) return name
        val dot = name.lastIndexOf('.')
        return if (dot > 0) {
            name.substring(0, dot) + " (" + n + ")" + name.substring(dot)
        } else {
            "$name ($n)"
        }
    }

    /** "video/mp4" for "x.mp4"; null if Android does not know the extension. */
    private fun guessMimeType(name: String): String? {
        val dot = name.lastIndexOf('.')
        if (dot < 0 || dot == name.length - 1) return null
        val ext = name.substring(dot + 1).lowercase(Locale.US)
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
    }

    // ------------------------------------------------------------------
    // Opening a new file for writing
    // ------------------------------------------------------------------

    /**
     * Creates a NEW file in the given location and opens it for writing.
     * Never overwrites: if the name is taken, a number is added.
     *
     * @Synchronized = only one thread at a time may run this, so two uploads
     * with the same name cannot grab the same file.
     */
    @Synchronized
    @Throws(IOException::class)
    fun openForWrite(ctx: Context, loc: SaveLocation, name: String, sizeBytes: Long): OpenFile {
        return when (loc.type) {
            TYPE_MEDIA -> openMediaStore(ctx, loc, name)
            TYPE_APPDIR -> openAppDir(ctx, loc, name, sizeBytes)
            TYPE_FOLDER -> openAppDir(ctx, loc, name, sizeBytes)   // same code: a plain folder
            TYPE_SAF -> openSaf(ctx, loc, name)
            else -> throw IOException("Unknown save location")
        }
    }

    // ----- 1. MediaStore (public Download folder) -----

    private fun openMediaStore(ctx: Context, loc: SaveLocation, name: String): OpenFile {
        if (Build.VERSION.SDK_INT < 29) throw IOException("Needs Android 10 or newer")
        val resolver = ctx.contentResolver

        // Describe the new file. IS_PENDING = 1 means "still being written,
        // hide it from other apps for now".
        val values = ContentValues()
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
        values.put(
            MediaStore.MediaColumns.RELATIVE_PATH,
            Environment.DIRECTORY_DOWNLOADS + "/" + PUBLIC_FOLDER
        )
        values.put(MediaStore.MediaColumns.IS_PENDING, 1)
        val mime = guessMimeType(name)
        if (mime != null) values.put(MediaStore.MediaColumns.MIME_TYPE, mime)

        // insert() creates the (empty) file. If the name already exists,
        // MediaStore itself picks "name (1).ext" - it never overwrites.
        val collection = MediaStore.Downloads.getContentUri(loc.value)
        val uri = resolver.insert(collection, values)
            ?: throw IOException("The system refused to create the file")

        val out = try {
            resolver.openOutputStream(uri)
        } catch (e: Exception) {
            null
        }
        if (out == null) {
            try {
                resolver.delete(uri, null, null)
            } catch (e: Exception) {
                // ignore
            }
            throw IOException("Cannot open the new file for writing")
        }

        return OpenFile(
            out,
            onFinish = {
                // Writing is done: make the file visible.
                val done = ContentValues()
                done.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(uri, done, null, null)

                // Ask which name the file really got (it may have a number now).
                var finalName = name
                val cursor = resolver.query(
                    uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null
                )
                if (cursor != null) {
                    cursor.use {
                        if (it.moveToFirst()) {
                            val n = it.getString(0)
                            if (!n.isNullOrEmpty()) finalName = n
                        }
                    }
                }
                finalName
            },
            onAbort = { resolver.delete(uri, null, null) }
        )
    }

    // ----- 2. The app's own folder (plain java.io.File) -----

    private fun openAppDir(ctx: Context, loc: SaveLocation, name: String, sizeBytes: Long): OpenFile {
        ctx.getExternalFilesDirs(null)          // makes Android create the app folders
        val dir = File(loc.value)
        if (!dir.isDirectory && !dir.mkdirs()) {
            throw IOException("Cannot create the folder ${loc.value}")
        }
        val free = dir.usableSpace               // 0 means "unknown"
        if (free > 0 && sizeBytes > free) {
            throw IOException("Not enough free space")
        }
        val file = createUniqueFile(dir, name)
        val out = try {
            file.outputStream()
        } catch (e: IOException) {
            file.delete()
            throw e
        }
        return OpenFile(
            out,
            onFinish = {
                // Tell Android's media index about the new file, so video players
                // and galleries find it right away.
                try {
                    MediaScannerConnection.scanFile(ctx, arrayOf(file.absolutePath), null, null)
                } catch (e: Exception) {
                    // Not important; the file is saved either way.
                }
                file.name
            },
            onAbort = { file.delete() }
        )
    }

    /** Tries "name", "name (1)", "name (2)", ... until one does not exist yet. */
    private fun createUniqueFile(dir: File, name: String): File {
        for (n in 0..9999) {
            val candidate = File(dir, numbered(name, n))
            // createNewFile() returns false if the file already exists.
            if (candidate.createNewFile()) return candidate
        }
        throw IOException("Too many files with the same name")
    }

    // ----- 3. Folder chosen with the system picker (SAF) -----

    private fun openSaf(ctx: Context, loc: SaveLocation, name: String): OpenFile {
        val resolver = ctx.contentResolver
        val tree = Uri.parse(loc.value)
        val folderId = DocumentsContract.getTreeDocumentId(tree)
        val folder = DocumentsContract.buildDocumentUriUsingTree(tree, folderId)

        // Read the names that already exist in the folder (lower case, because
        // USB drives treat "A.mp4" and "a.mp4" as the same file).
        val existing = HashSet<String>()
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, folderId)
        val cursor = resolver.query(
            children, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null
        )
        if (cursor != null) {
            cursor.use {
                while (it.moveToNext()) {
                    val n = it.getString(0)
                    if (n != null) existing.add(n.lowercase(Locale.ROOT))
                }
            }
        }

        // Find the first free name.
        var finalName = name
        var n = 0
        while (existing.contains(finalName.lowercase(Locale.ROOT)) && n < 9999) {
            n++
            finalName = numbered(name, n)
        }

        val mime = guessMimeType(finalName) ?: "application/octet-stream"
        val doc = DocumentsContract.createDocument(resolver, folder, mime, finalName)
            ?: throw IOException("Cannot create the file in the picked folder")

        val out = try {
            resolver.openOutputStream(doc)
        } catch (e: Exception) {
            null
        }
        if (out == null) {
            try {
                DocumentsContract.deleteDocument(resolver, doc)
            } catch (e: Exception) {
                // ignore
            }
            throw IOException("Cannot open the new file for writing")
        }

        val savedName = finalName
        return OpenFile(
            out,
            onFinish = { savedName },
            onAbort = { DocumentsContract.deleteDocument(resolver, doc) }
        )
    }
}
