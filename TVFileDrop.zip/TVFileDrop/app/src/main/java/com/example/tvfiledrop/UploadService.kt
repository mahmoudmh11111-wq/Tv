package com.example.tvfiledrop

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder

/**
 * A "foreground service": a part of the app with no screen that Android
 * keeps alive while it shows a notification. It owns the web server, so
 * uploads continue even if you press Home on the remote.
 *
 * Life cycle:
 *   startService(...)  -> onCreate()  -> the server starts
 *   stopService(...)   -> onDestroy() -> the server stops
 */
class UploadService : Service() {

    private var server: WebServer? = null

    /** We do not use "binding", so this just returns null. */
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        // Android requires a foreground service to show its notification
        // within a few seconds of starting, so we do it first.
        try {
            startForeground(NOTIFICATION_ID, buildNotification())
        } catch (e: Exception) {
            // On some systems this can be refused. The server still works
            // while the app is open, so we carry on.
        }
        startServer()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // NOT_STICKY: if Android ever kills the app, do not restart on its own.
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        server?.stop()          // also cuts off any upload that is in progress
        server = null
        AppState.running = false
        AppState.port = 0
        AppState.setStatus("Server is stopped")
        super.onDestroy()
    }

    /** Tries port 8080 first; if another app uses it, tries 8081, 8082, ... */
    private fun startServer() {
        for (port in FIRST_PORT until FIRST_PORT + 10) {
            try {
                val s = WebServer(applicationContext, port)
                // 30 000 = give up on a connection that sends nothing for 30 seconds.
                // false  = normal (non-daemon) threads.
                s.start(30_000, false)
                server = s
                AppState.running = true
                AppState.port = port
                AppState.setStatus("Waiting for files…")
                return
            } catch (e: Exception) {
                // Port busy (or another problem) - try the next one.
            }
        }
        AppState.running = false
        AppState.setStatus("Could not start the server (ports 8080-8089 are busy)")
        stopSelf()
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        // Tapping the notification opens the app.
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )

        val builder = if (Build.VERSION.SDK_INT >= 26) {
            // Android 8+ wants notifications sorted into "channels".
            val channel = NotificationChannel(
                CHANNEL_ID, "File receiving", NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }

        return builder
            .setContentTitle("TV File Drop")
            .setContentText("Ready to receive files")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(openApp)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val NOTIFICATION_ID = 1
        private const val CHANNEL_ID = "receiving"
        private const val FIRST_PORT = 8080
    }
}
