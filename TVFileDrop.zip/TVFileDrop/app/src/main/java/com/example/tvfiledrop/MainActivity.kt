package com.example.tvfiledrop

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import java.io.File

/**
 * The one screen of the app.
 *
 * It does three things:
 *   1. Shows the current state (address, QR code, save location, status, recent files).
 *   2. Reacts to the four buttons.
 *   3. Starts / stops UploadService, which runs the web server.
 *
 * It never receives files itself - the service and WebServer do that.
 */
class MainActivity : Activity() {

    // The views from res/layout/activity_main.xml. "lateinit" = filled in onCreate.
    private lateinit var addressText: TextView
    private lateinit var pinText: TextView
    private lateinit var qrImage: ImageView
    private lateinit var locationText: TextView
    private lateinit var statusText: TextView
    private lateinit var recentText: TextView
    private lateinit var changeLocationButton: Button
    private lateinit var startStopButton: Button
    private lateinit var pinButton: Button

    /** The text currently drawn as a QR code, so we only redraw when it changes. */
    private var shownQrText = ""

    /** Redraws the screen every 5 seconds, to notice Wi-Fi or USB changes. */
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            render()
            handler.postDelayed(this, 5000)
        }
    }

    // ------------------------------------------------------------------
    // Life cycle
    // ------------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        addressText = findViewById(R.id.addressText)
        pinText = findViewById(R.id.pinText)
        qrImage = findViewById(R.id.qrImage)
        locationText = findViewById(R.id.locationText)
        statusText = findViewById(R.id.statusText)
        recentText = findViewById(R.id.recentText)
        changeLocationButton = findViewById(R.id.changeLocationButton)
        startStopButton = findViewById(R.id.startStopButton)
        pinButton = findViewById(R.id.pinButton)

        changeLocationButton.setOnClickListener { showLocationDialog() }
        startStopButton.setOnClickListener {
            if (AppState.running) stopServer() else startServer()
        }
        pinButton.setOnClickListener {
            Prefs.setPinEnabled(this, !Prefs.isPinEnabled(this))
            render()
        }

        // Make the focused button grow a little, so it is obvious on a TV.
        addFocusEffect(changeLocationButton)
        addFocusEffect(startStopButton)
        addFocusEffect(pinButton)
        startStopButton.requestFocus()

        // Start the server automatically when the app is opened for the first time.
        if (savedInstanceState == null && !AppState.running) {
            startServer()
        }
    }

    /** Called when the screen becomes visible. */
    override fun onStart() {
        super.onStart()
        AppState.listener = { render() }   // "tell me when something changes"
        handler.post(ticker)               // draws now, then every 5 seconds
    }

    /** Called when the screen is no longer visible. */
    override fun onStop() {
        super.onStop()
        AppState.listener = null
        handler.removeCallbacks(ticker)
    }

    // ------------------------------------------------------------------
    // Starting and stopping the server
    // ------------------------------------------------------------------

    private fun startServer() {
        val intent = Intent(this, UploadService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
        } catch (e: Exception) {
            AppState.showStatus("Could not start the server: " + (e.message ?: "unknown error"))
        }
    }

    private fun stopServer() {
        stopService(Intent(this, UploadService::class.java))
    }

    // ------------------------------------------------------------------
    // Drawing the screen
    // ------------------------------------------------------------------

    /** Reads the current state and puts it on the screen. Cheap, so we call it often. */
    private fun render() {
        val running = AppState.running
        val ip = NetUtils.getLocalIp()

        // Address + QR code
        val address = if (running && ip != null) "http://" + ip + ":" + AppState.port else ""
        addressText.text = when {
            !running -> "Server is stopped"
            ip == null -> "No network connection"
            else -> address
        }
        if (address != shownQrText) {
            shownQrText = address
            if (address.isEmpty()) {
                qrImage.setImageDrawable(null)
                qrImage.visibility = View.INVISIBLE
            } else {
                try {
                    qrImage.setImageBitmap(QrCode.make(address, 480))
                    qrImage.visibility = View.VISIBLE
                } catch (e: Exception) {
                    qrImage.visibility = View.INVISIBLE
                }
            }
        }

        // PIN
        val pinOn = Prefs.isPinEnabled(this)
        pinText.text = if (pinOn) "PIN:  " + Prefs.getPin(this) else "PIN: off (anyone on your Wi-Fi can send)"
        pinButton.text = if (pinOn) "Turn PIN off" else "Turn PIN on"

        // Save location
        val (location, fellBack) = Storage.resolve(this)
        locationText.text = if (fellBack) {
            "USB drive not found – using for now:\n" + location.label
        } else {
            location.label
        }

        // Button, status, recent files
        startStopButton.text = if (running) "Stop server" else "Start server"
        statusText.text = AppState.status
        val recent = Prefs.getRecent(this)
        recentText.text = if (recent.isEmpty()) "Nothing yet" else recent.joinToString("\n")

        // Do not let the TV go to sleep / screensaver while the server is running.
        if (running) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun addFocusEffect(view: View) {
        view.setOnFocusChangeListener { v, hasFocus ->
            val scale = if (hasFocus) 1.06f else 1.0f
            v.animate().scaleX(scale).scaleY(scale).setDuration(120).start()
        }
    }

    // ------------------------------------------------------------------
    // "Change location"
    // ------------------------------------------------------------------

    private fun showLocationDialog() {
        val locations = Storage.listLocations(this)
        val pickerExists = isFolderPickerAvailable()

        // The list the user sees: all detected storage, plus one last line for the picker.
        val labels = ArrayList<String>()
        for (loc in locations) labels.add(loc.label)
        labels.add("Browse folders: choose any folder…")
        labels.add(
            if (pickerExists) "Choose any folder with the system picker…"
            else "System folder picker: not available on this TV"
        )

        AlertDialog.Builder(this)
            .setTitle("Where should received files be saved?")
            .setItems(labels.toTypedArray()) { _, index ->
                if (index < locations.size) {
                    chooseLocation(locations[index])
                } else if (index == locations.size) {
                    startBrowsing()
                } else if (pickerExists) {
                    openFolderPicker()
                } else {
                    showMessage(
                        "No folder picker",
                        "This TV does not include Android's folder picker (many TVs do not). " +
                            "Pick one of the storage entries in the list instead - " +
                            "they work without it."
                    )
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun chooseLocation(location: SaveLocation) {
        Prefs.setLocation(this, location)
        render()
        // Tell the user exactly where files will end up, and why.
        showMessage(location.label, Storage.explain(location))
    }

    /**
     * Does this TV have the system folder picker?
     * Some TVs have no picker at all; others have a fake "stub" that only
     * shows an error. We treat both as "not available".
     */
    private fun isFolderPickerAvailable(): Boolean {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        val component = intent.resolveActivity(packageManager) ?: return false
        return !component.packageName.contains("stubs", ignoreCase = true)
    }

    private fun openFolderPicker() {
        try {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQUEST_PICK_FOLDER)
        } catch (e: ActivityNotFoundException) {
            showMessage(
                "No folder picker",
                "The folder picker could not be opened on this TV. " +
                    "Pick one of the storage entries in the list instead."
            )
        }
    }

    /** Android calls this when the folder picker closes. */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Coming back from the "All files access" settings screen.
        if (requestCode == REQUEST_ALL_FILES) {
            if (hasFullStorageAccess()) {
                showStorageRoots()
            } else {
                showMessage("Permission not granted", ADB_HELP)
            }
            return
        }

        // Coming back from the system folder picker.
        if (requestCode != REQUEST_PICK_FOLDER || resultCode != RESULT_OK) return
        val folder: Uri = data?.data ?: return

        try {
            // "Persistable" = keep this access after the app or the TV restarts.
            contentResolver.takePersistableUriPermission(
                folder,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            // The ID looks like "1234-ABCD:Movies" or "primary:Download" - good enough as a name.
            val name = DocumentsContract.getTreeDocumentId(folder)
            chooseLocation(
                SaveLocation(Storage.TYPE_SAF, folder.toString(), "Picked folder: $name")
            )
        } catch (e: Exception) {
            showMessage("Could not use that folder", e.message ?: "Unknown error")
        }
    }

    // ------------------------------------------------------------------
    // "Browse folders": the app's own folder browser
    // ------------------------------------------------------------------

    /**
     * May the app read and write every folder?
     * Android 11+: the user must have switched on "All files access".
     * Older versions: the normal storage permission.
     */
    private fun hasFullStorageAccess(): Boolean {
        return if (Build.VERSION.SDK_INT >= 30) {
            Environment.isExternalStorageManager()
        } else {
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
        }
    }

    /** Step 1: make sure we have the permission, then show the browser. */
    private fun startBrowsing() {
        if (hasFullStorageAccess()) {
            showStorageRoots()
            return
        }
        if (Build.VERSION.SDK_INT >= 30) {
            AlertDialog.Builder(this)
                .setTitle("Permission needed")
                .setMessage(
                    "To browse and save into any folder, Android requires the " +
                        "'All files access' permission.\n\n" +
                        "Press 'Open settings', switch it ON for TV File Drop, " +
                        "then press Back on the remote."
                )
                .setPositiveButton("Open settings") { _, _ -> openAllFilesSettings() }
                .setNegativeButton("Cancel", null)
                .show()
        } else {
            requestPermissions(
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQUEST_STORAGE_PERMISSION
            )
        }
    }

    /** Opens the "All files access" screen. Some TVs do not have it - then we explain adb. */
    private fun openAllFilesSettings() {
        try {
            // First try the screen for exactly this app...
            startActivityForResult(
                Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")
                ),
                REQUEST_ALL_FILES
            )
        } catch (e: Exception) {
            try {
                // ...then the general list of apps.
                startActivityForResult(
                    Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION), REQUEST_ALL_FILES
                )
            } catch (e2: Exception) {
                showMessage("This TV has no 'All files access' screen", ADB_HELP)
            }
        }
    }

    /** Android calls this after the permission pop-up on Android 10 and older. */
    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQUEST_STORAGE_PERMISSION) return
        if (hasFullStorageAccess()) {
            showStorageRoots()
        } else {
            showMessage("Permission not granted", "Without it the app cannot browse folders.")
        }
    }

    /** Step 2: choose internal storage or a USB drive. */
    private fun showStorageRoots() {
        val roots = Storage.browseRoots(this)
        val labels = ArrayList<String>()
        for (root in roots) labels.add(root.first)

        AlertDialog.Builder(this)
            .setTitle("Browse: choose a storage")
            .setItems(labels.toTypedArray()) { _, index ->
                showFolder(roots[index].second, roots[index].second)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /**
     * Step 3: show one folder. The first three lines are actions, the rest are
     * the folders inside it. Choosing a folder opens this same dialog again
     * for that folder - that is all "browsing" is.
     *
     * root = the top folder of this storage (we never go above it)
     * dir  = the folder being shown
     */
    private fun showFolder(root: File, dir: File) {
        val subfolders = Storage.listSubfolders(dir)
        val atTop = dir == root

        val labels = ArrayList<String>()
        labels.add("✓  SAVE FILES IN THIS FOLDER")
        labels.add("+  New folder here…")
        labels.add(if (atTop) "←  Back to the storage list" else "↑  Up one level")
        for (folder in subfolders) labels.add(folder.name + "/")

        AlertDialog.Builder(this)
            .setTitle(dir.absolutePath)
            .setItems(labels.toTypedArray()) { _, index ->
                when (index) {
                    0 -> chooseFolder(root, dir)
                    1 -> askNewFolderName(root, dir)
                    2 -> if (atTop) showStorageRoots() else showFolder(root, dir.parentFile ?: root)
                    else -> showFolder(root, subfolders[index - 3])
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun chooseFolder(root: File, dir: File) {
        if (!dir.canWrite()) {
            AlertDialog.Builder(this)
                .setTitle("Cannot save here")
                .setMessage("Android does not let the app write into this folder. Choose another one.")
                .setPositiveButton("OK") { _, _ -> showFolder(root, dir) }
                .show()
            return
        }
        chooseLocation(
            SaveLocation(Storage.TYPE_FOLDER, dir.absolutePath, "Folder: " + dir.absolutePath)
        )
    }

    /** Asks for a name with the on-screen keyboard and creates that folder. */
    private fun askNewFolderName(root: File, dir: File) {
        val input = EditText(this)
        input.setSingleLine()
        input.hint = "Folder name"

        AlertDialog.Builder(this)
            .setTitle("New folder in " + dir.name)
            .setView(input)
            .setPositiveButton("Create") { _, _ ->
                val typed = input.text.toString().trim()
                if (typed.isEmpty()) {
                    showFolder(root, dir)
                } else {
                    val created = File(dir, Storage.cleanFileName(typed))
                    if (created.isDirectory || created.mkdirs()) {
                        showFolder(root, created)      // go straight into the new folder
                    } else {
                        AlertDialog.Builder(this)
                            .setTitle("Could not create the folder")
                            .setMessage("Android does not allow a new folder here.")
                            .setPositiveButton("OK") { _, _ -> showFolder(root, dir) }
                            .show()
                    }
                }
            }
            .setNegativeButton("Cancel") { _, _ -> showFolder(root, dir) }
            .show()
    }

    private fun showMessage(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    companion object {
        private const val REQUEST_PICK_FOLDER = 100
        private const val REQUEST_ALL_FILES = 101
        private const val REQUEST_STORAGE_PERMISSION = 102

        /** Shown when "All files access" cannot be switched on from the TV itself. */
        private const val ADB_HELP =
            "'All files access' is still off.\n\n" +
                "If your TV has no settings screen for it, you can switch it on " +
                "from a computer:\n" +
                "1. Turn on USB debugging on the TV.\n" +
                "2. adb connect <TV address>:5555\n" +
                "3. adb shell appops set com.example.tvfiledrop MANAGE_EXTERNAL_STORAGE allow\n\n" +
                "Then open 'Browse folders' again. Until then, the other " +
                "locations in the list still work."
    }
}
