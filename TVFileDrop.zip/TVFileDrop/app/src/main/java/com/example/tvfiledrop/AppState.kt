package com.example.tvfiledrop

import android.os.Handler
import android.os.Looper

/**
 * A tiny "notice board" shared by the whole app.
 *
 * The web server (running on background threads) writes what is happening here,
 * and the screen (MainActivity) reads it. "object" means there is exactly one
 * AppState in the app.
 */
object AppState {

    /** True while the web server is running. */
    @Volatile
    var running = false

    /** The port the server listens on (normally 8080). */
    @Volatile
    var port = 0

    /** The status line shown on the TV, e.g. "Receiving movie.mp4 – 45%". */
    @Volatile
    var status = "Server is stopped"

    /** MainActivity puts a function here; we call it whenever something changes. */
    @Volatile
    var listener: (() -> Unit)? = null

    // Android only allows the "main thread" to touch the screen. This Handler
    // lets background threads say "please run this on the main thread".
    private val mainHandler = Handler(Looper.getMainLooper())

    /** Change the status line and tell the screen to redraw. */
    fun showStatus(text: String) {
        status = text
        notifyChanged()
    }

    /** Ask the screen to redraw (safe to call from any thread). */
    fun notifyChanged() {
        mainHandler.post { listener?.invoke() }
    }
}
