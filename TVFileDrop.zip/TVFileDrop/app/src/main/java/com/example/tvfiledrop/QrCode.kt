package com.example.tvfiledrop

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter

object QrCode {

    /**
     * Turns a text (our web address) into a QR code picture.
     *
     * ZXing gives us a grid of true/false values ("is this square black?").
     * We copy that grid into a Bitmap, one pixel at a time.
     */
    fun make(text: String, sizePx: Int): Bitmap {
        val hints = mapOf(EncodeHintType.MARGIN to 1)   // thin white border
        val matrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, sizePx, sizePx, hints)
        val width = matrix.width
        val height = matrix.height
        val pixels = IntArray(width * height)
        for (y in 0 until height) {
            for (x in 0 until width) {
                pixels[y * width + x] = if (matrix.get(x, y)) Color.BLACK else Color.WHITE
            }
        }
        // RGB_565 uses half the memory of the default format - plenty for black & white.
        return Bitmap.createBitmap(pixels, width, height, Bitmap.Config.RGB_565)
    }
}
