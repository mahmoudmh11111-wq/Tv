package com.example.tvfiledrop

import android.content.Context
import fi.iki.elonen.NanoHTTPD
import java.io.IOException

/**
 * The small web server the iPad talks to.
 *
 * NanoHTTPD does the low-level network work. For every request from the
 * browser it calls serve() below, and we decide what to answer.
 *
 * The addresses ("routes") we understand:
 *   GET  /              -> the web page (index.html from the assets folder)
 *   GET  /api/info      -> tells the page whether a PIN is needed
 *   GET  /api/check     -> checks the PIN before any file is sent
 *   POST /api/upload    -> receives ONE file; the request body IS the file
 *
 * Note: each request runs on its own background thread, never on the main
 * (screen) thread. That is why we talk to the screen only through AppState.
 */
class WebServer(private val context: Context, port: Int) : NanoHTTPD(port) {

    /** The web page, loaded once from app/src/main/assets/index.html. */
    private val pageHtml: String =
        context.assets.open("index.html").bufferedReader(Charsets.UTF_8).use { it.readText() }

    // Simple protection against guessing the PIN: after 5 wrong tries,
    // nobody can try again for 60 seconds.
    private var wrongPinCount = 0
    private var lockedUntil = 0L

    override fun serve(session: NanoHTTPD.IHTTPSession): NanoHTTPD.Response {
        val uri = session.uri ?: "/"
        val method = session.method
        return try {
            when {
                method == NanoHTTPD.Method.GET && (uri == "/" || uri == "/index.html") -> {
                    val response = NanoHTTPD.newFixedLengthResponse(
                        NanoHTTPD.Response.Status.OK, "text/html; charset=utf-8", pageHtml
                    )
                    response.addHeader("Cache-Control", "no-store")
                    response
                }

                method == NanoHTTPD.Method.GET && uri == "/api/info" ->
                    json(
                        NanoHTTPD.Response.Status.OK,
                        "{\"pin\":" + Prefs.isPinEnabled(context) + "}"
                    )

                method == NanoHTTPD.Method.GET && uri == "/api/check" -> {
                    val problem = checkPin(session)
                    if (problem == null) {
                        json(NanoHTTPD.Response.Status.OK, "{\"ok\":true}")
                    } else {
                        errorJson(NanoHTTPD.Response.Status.FORBIDDEN, problem)
                    }
                }

                method == NanoHTTPD.Method.POST && uri == "/api/upload" -> handleUpload(session)

                else -> closing(errorJson(NanoHTTPD.Response.Status.NOT_FOUND, "Not found"))
            }
        } catch (e: Exception) {
            closing(errorJson(NanoHTTPD.Response.Status.INTERNAL_ERROR, e.message ?: "Server error"))
        }
    }

    // ------------------------------------------------------------------
    // Receiving one file
    // ------------------------------------------------------------------

    private fun handleUpload(session: NanoHTTPD.IHTTPSession): NanoHTTPD.Response {
        // 1. PIN
        val pinProblem = checkPin(session)
        if (pinProblem != null) {
            return closing(errorJson(NanoHTTPD.Response.Status.FORBIDDEN, pinProblem))
        }

        // 2. File name (sent as ?name=... in the address) and size (Content-Length header).
        //    NanoHTTPD gives us all header names in lower case.
        val rawName = session.parameters["name"]?.firstOrNull() ?: "file"
        val name = Storage.cleanFileName(rawName)
        val length = session.headers["content-length"]?.trim()?.toLongOrNull()
        if (length == null || length < 0) {
            return closing(errorJson(NanoHTTPD.Response.Status.BAD_REQUEST, "Missing file size"))
        }

        // 3. Decide where to save, and create the empty file there.
        val (location, fellBack) = Storage.resolve(context)
        val target: OpenFile = try {
            Storage.openForWrite(context, location, name, length)
        } catch (e: Exception) {
            val reason = friendly(e)
            AppState.showStatus("Failed: $name – $reason")
            return closing(errorJson(NanoHTTPD.Response.Status.INTERNAL_ERROR, reason))
        }

        // 4. Copy the bytes: network -> small buffer -> disk, again and again.
        //    Only 64 KB is ever in memory, no matter how big the file is.
        val buffer = ByteArray(64 * 1024)
        var received = 0L
        var lastPercent = -1
        try {
            val input = session.inputStream
            while (received < length) {
                val wanted = minOf(buffer.size.toLong(), length - received).toInt()
                val count = input.read(buffer, 0, wanted)
                if (count < 0) throw IOException("The connection was lost")
                target.out.write(buffer, 0, count)
                received += count

                // Update the TV screen, but only when the percentage changes.
                val percent = (received * 100 / length).toInt()
                if (percent != lastPercent) {
                    lastPercent = percent
                    AppState.showStatus("Receiving $name – $percent%")
                }
            }
            target.out.flush()
            target.out.close()

            // 5. Finished. Remember it and tell the browser.
            val savedName = target.finish()
            Prefs.addRecent(context, savedName + "  (" + readableSize(length) + ")")
            val note = if (fellBack) " (USB drive not found – saved to internal storage)" else ""
            AppState.showStatus("Received $savedName ✓$note")
            return json(
                NanoHTTPD.Response.Status.OK,
                "{\"ok\":true,\"name\":\"" + escape(savedName) + "\"}"
            )
        } catch (e: Exception) {
            // Something broke (drive full, drive unplugged, Wi-Fi dropped, server stopped...).
            // Close and delete the half-written file so no broken files are left behind.
            try {
                target.out.close()
            } catch (ignored: Exception) {
            }
            target.abort()
            val reason = friendly(e)
            AppState.showStatus("Failed: $name – $reason")
            return closing(errorJson(NanoHTTPD.Response.Status.INTERNAL_ERROR, reason))
        }
    }

    // ------------------------------------------------------------------
    // PIN
    // ------------------------------------------------------------------

    /** Returns null if the PIN is fine (or no PIN is needed), else an error text. */
    @Synchronized
    private fun checkPin(session: NanoHTTPD.IHTTPSession): String? {
        if (!Prefs.isPinEnabled(context)) return null

        val now = System.currentTimeMillis()
        if (now < lockedUntil) {
            return "Too many wrong PINs. Wait a minute and try again."
        }
        val given = session.headers["x-pin"]?.trim() ?: ""
        if (given == Prefs.getPin(context)) {
            wrongPinCount = 0
            return null
        }
        wrongPinCount++
        if (wrongPinCount >= 5) {
            wrongPinCount = 0
            lockedUntil = now + 60_000
        }
        return "Wrong PIN. Look at the TV screen."
    }

    // ------------------------------------------------------------------
    // Small helpers
    // ------------------------------------------------------------------

    private fun json(status: NanoHTTPD.Response.Status, body: String): NanoHTTPD.Response {
        val response = NanoHTTPD.newFixedLengthResponse(
            status, "application/json; charset=utf-8", body
        )
        response.addHeader("Cache-Control", "no-store")
        return response
    }

    private fun errorJson(status: NanoHTTPD.Response.Status, message: String): NanoHTTPD.Response {
        return json(status, "{\"ok\":false,\"error\":\"" + escape(message) + "\"}")
    }

    /**
     * When we answer BEFORE reading the whole upload, the rest of the file is
     * still on its way. "Connection: close" tells NanoHTTPD to hang up instead
     * of trying to read that leftover data as a new request.
     */
    private fun closing(response: NanoHTTPD.Response): NanoHTTPD.Response {
        response.addHeader("Connection", "close")
        return response
    }

    /** Makes a text safe to put between quotes in JSON. */
    private fun escape(text: String): String {
        val sb = StringBuilder()
        for (ch in text) {
            when {
                ch == '"' -> sb.append("\\\"")
                ch == '\\' -> sb.append("\\\\")
                ch.code < 32 -> sb.append(' ')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    /** Turns a technical error into a sentence a person can act on. */
    private fun friendly(e: Exception): String {
        val message = e.message ?: e.javaClass.simpleName
        return when {
            message.contains("ENOSPC") || message.contains("No space left") ->
                "The storage is full"
            message.contains("EFBIG") || message.contains("File too large") ->
                "File too big for this drive (FAT32 drives cannot hold files over 4 GB)"
            message.contains("Socket closed") || message.contains("Connection reset") ->
                "The connection was lost"
            else -> message
        }
    }

    private fun readableSize(bytes: Long): String {
        return when {
            bytes >= 1024L * 1024 * 1024 ->
                String.format("%.2f GB", bytes / (1024.0 * 1024 * 1024))
            bytes >= 1024L * 1024 ->
                String.format("%.1f MB", bytes / (1024.0 * 1024))
            bytes >= 1024L ->
                String.format("%d KB", bytes / 1024)
            else -> "$bytes bytes"
        }
    }
}
