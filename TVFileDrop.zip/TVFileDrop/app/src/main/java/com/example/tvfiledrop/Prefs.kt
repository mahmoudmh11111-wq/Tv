package com.example.tvfiledrop

import android.content.Context
import android.content.SharedPreferences
import java.security.SecureRandom

/**
 * Small settings that must survive closing the app:
 * the chosen save location, the PIN, and the list of recent files.
 *
 * SharedPreferences is Android's built-in key/value store (a small XML file
 * inside the app's private storage).
 */
object Prefs {

    private const val KEY_LOC_TYPE = "loc_type"
    private const val KEY_LOC_VALUE = "loc_value"
    private const val KEY_LOC_LABEL = "loc_label"
    private const val KEY_PIN_ENABLED = "pin_enabled"
    private const val KEY_PIN = "pin"
    private const val KEY_RECENT = "recent"

    /** How many received files the TV screen remembers. */
    private const val MAX_RECENT = 5

    private fun sp(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    // ---------- Save location ----------

    /** The location the user picked, or null if they never picked one. */
    fun getLocation(ctx: Context): SaveLocation? {
        val p = sp(ctx)
        val type = p.getString(KEY_LOC_TYPE, null) ?: return null
        val value = p.getString(KEY_LOC_VALUE, null) ?: return null
        val label = p.getString(KEY_LOC_LABEL, null) ?: value
        return SaveLocation(type, value, label)
    }

    fun setLocation(ctx: Context, loc: SaveLocation) {
        sp(ctx).edit()
            .putString(KEY_LOC_TYPE, loc.type)
            .putString(KEY_LOC_VALUE, loc.value)
            .putString(KEY_LOC_LABEL, loc.label)
            .apply()
    }

    // ---------- PIN ----------

    fun isPinEnabled(ctx: Context): Boolean = sp(ctx).getBoolean(KEY_PIN_ENABLED, false)

    fun getPin(ctx: Context): String = sp(ctx).getString(KEY_PIN, "") ?: ""

    /** Turning the PIN on creates a fresh random 4-digit PIN. */
    fun setPinEnabled(ctx: Context, enabled: Boolean) {
        val editor = sp(ctx).edit().putBoolean(KEY_PIN_ENABLED, enabled)
        if (enabled) {
            val number = SecureRandom().nextInt(10000)          // 0..9999
            editor.putString(KEY_PIN, number.toString().padStart(4, '0'))
        }
        editor.apply()
    }

    // ---------- Recent files ----------

    /** Newest first. Each entry is one line of text. */
    fun getRecent(ctx: Context): List<String> {
        val text = sp(ctx).getString(KEY_RECENT, "") ?: ""
        return if (text.isEmpty()) emptyList() else text.split("\n")
    }

    @Synchronized
    fun addRecent(ctx: Context, line: String) {
        val list = ArrayList<String>()
        list.add(line.replace("\n", " "))
        list.addAll(getRecent(ctx))
        while (list.size > MAX_RECENT) {
            list.removeAt(list.size - 1)
        }
        sp(ctx).edit().putString(KEY_RECENT, list.joinToString("\n")).apply()
    }
}
