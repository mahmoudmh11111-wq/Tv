package com.example.tvfiledrop

import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections

object NetUtils {

    /**
     * Finds the TV's address on the home network, for example "192.168.1.20".
     * Returns null if the TV is not connected.
     *
     * A device can have several network "interfaces" (Wi-Fi is usually called
     * wlan0, a network cable eth0). We look at all of them and prefer Wi-Fi,
     * then cable, then anything else. No permission is needed for this.
     */
    fun getLocalIp(): String? {
        var wifi: String? = null
        var cable: String? = null
        var other: String? = null
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return null
            for (ni in Collections.list(interfaces)) {
                if (!ni.isUp || ni.isLoopback) continue
                for (address in Collections.list(ni.inetAddresses)) {
                    // Only normal IPv4 home-network addresses (192.168.x.x, 10.x.x.x, ...).
                    if (address !is Inet4Address) continue
                    if (address.isLoopbackAddress || !address.isSiteLocalAddress) continue
                    val ip = address.hostAddress ?: continue
                    val name = ni.name ?: ""
                    when {
                        name.startsWith("wlan") -> if (wifi == null) wifi = ip
                        name.startsWith("eth") -> if (cable == null) cable = ip
                        else -> if (other == null) other = ip
                    }
                }
            }
        } catch (e: Exception) {
            return null
        }
        return wifi ?: cable ?: other
    }
}
